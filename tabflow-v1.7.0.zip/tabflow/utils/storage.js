// Chrome Storage wrapper
import { STORAGE_KEYS, DEFAULTS, MAX_CLOSED_TABS } from './constants.js';

export async function getSettings() {
  const result = await chrome.storage.local.get(STORAGE_KEYS.settings);
  return { ...DEFAULTS, ...result[STORAGE_KEYS.settings] };
}

export async function saveSettings(settings) {
  await chrome.storage.local.set({ [STORAGE_KEYS.settings]: settings });
}

export async function getClosedTabs() {
  const result = await chrome.storage.local.get(STORAGE_KEYS.closedTabs);
  return result[STORAGE_KEYS.closedTabs] || [];
}

export async function addClosedTab(tab) {
  const tabs = await getClosedTabs();
  tabs.unshift({ ...tab, closedAt: Date.now() });
  if (tabs.length > MAX_CLOSED_TABS) tabs.length = MAX_CLOSED_TABS;
  await chrome.storage.local.set({ [STORAGE_KEYS.closedTabs]: tabs });
}

export async function removeClosedTab(url) {
  const tabs = await getClosedTabs();
  const filtered = tabs.filter(t => t.url !== url);
  await chrome.storage.local.set({ [STORAGE_KEYS.closedTabs]: filtered });
}

export async function clearClosedTabs() {
  await chrome.storage.local.set({ [STORAGE_KEYS.closedTabs]: [] });
}

export async function getTabActivity() {
  const result = await chrome.storage.local.get(STORAGE_KEYS.tabActivity);
  return result[STORAGE_KEYS.tabActivity] || {};
}

export async function updateTabActivity(tabId) {
  const activity = await getTabActivity();
  activity[tabId] = Date.now();
  await chrome.storage.local.set({ [STORAGE_KEYS.tabActivity]: activity });
}

export async function removeTabActivity(tabId) {
  const activity = await getTabActivity();
  delete activity[tabId];
  await chrome.storage.local.set({ [STORAGE_KEYS.tabActivity]: activity });
}

export async function getTabCategories() {
  const result = await chrome.storage.local.get(STORAGE_KEYS.tabCategories);
  return result[STORAGE_KEYS.tabCategories] || {};
}

export async function setTabCategory(tabId, category, summary, importance) {
  const cats = await getTabCategories();
  cats[tabId] = { category, summary, importance };
  await chrome.storage.local.set({ [STORAGE_KEYS.tabCategories]: cats });
}

export async function getStorageUsage() {
  if (chrome.storage.local.getBytesInUse) {
    const bytes = await chrome.storage.local.getBytesInUse(null);
    return { bytes, maxBytes: 5242880, percentUsed: Math.round((bytes / 5242880) * 100) };
  }
  return null;
}
