// TabFlow Constants
export const DEFAULTS = {
  inactiveThreshold: 30, // minutes
  maxTabs: 0, // 0 = unlimited
  theme: 'system', // 'light' | 'dark' | 'system'
  whitelist: ['localhost', 'mail.google.com', 'calendar.google.com', 'docs.google.com'],
};

export const CATEGORIES = {
  work: { label: 'Work', icon: '💼', color: '#3B82F6' },
  study: { label: 'Study', icon: '📚', color: '#8B5CF6' },
  entertainment: { label: 'Entertainment', icon: '🎮', color: '#F59E0B' },
  shopping: { label: 'Shopping', icon: '🛒', color: '#10B981' },
  social: { label: 'Social', icon: '💬', color: '#EC4899' },
  other: { label: 'Other', icon: '📄', color: '#6B7280' },
};

export const CATEGORY_RULES = {
  work: [/github\.com/, /gitlab/, /jira/, /slack\.com/, /notion\.so/, /figma\.com/, /linear\.app/, /trello/, /asana/, /confluence/, /bitbucket/, /vercel/, /netlify/, /aws\.amazon/, /console\.cloud/, /azure/, /stackoverflow/],
  study: [/wikipedia/, /coursera/, /udemy/, /edx\.org/, /khan/, /arxiv/, /scholar\.google/, /medium\.com/, /dev\.to/, /mdn/, /w3schools/, /leetcode/, /hackerrank/],
  entertainment: [/youtube\.com/, /netflix/, /twitch/, /spotify/, /reddit\.com/, /9gag/, /imgur/, /tiktok/, /bilibili/, /disneyplus/, /hulu/],
  shopping: [/amazon\./, /ebay/, /shopee/, /lazada/, /taobao/, /aliexpress/, /walmart/, /target\.com/, /etsy/, /shopify/],
  social: [/twitter\.com/, /x\.com/, /facebook/, /instagram/, /linkedin/, /discord/, /telegram/, /whatsapp/, /threads\.net/, /mastodon/],
};

export const IMPORTANCE_RULES = {
  high: [/docs\.google/, /github\.com.*\/(pull|issues)/, /mail\.google/, /calendar/, /notion\.so/, /figma\.com/],
  low: [/reddit\.com/, /youtube\.com\/watch/, /twitter\.com/, /x\.com/, /9gag/, /imgur/],
};

export const STORAGE_KEYS = {
  settings: 'tabflow_settings',
  closedTabs: 'tabflow_closed_tabs',
  tabActivity: 'tabflow_tab_activity',
  tabCategories: 'tabflow_tab_categories',
};

export const ALARM_NAME = 'tabflow_cleanup';
export const ALARM_INTERVAL = 1; // minutes
export const MAX_CLOSED_TABS = 200;
