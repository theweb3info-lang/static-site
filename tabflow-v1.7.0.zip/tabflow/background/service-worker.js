// TabFlow Service Worker
import { getSettings, addClosedTab, getClosedTabs } from '../utils/storage.js';
import { initTracker, getInactiveTabs } from '../utils/tab-tracker.js';
import { classifyTab, summarizeTab, getImportance } from '../utils/ai-engine.js';
import { ALARM_NAME, ALARM_INTERVAL } from '../utils/constants.js';

// Temporary whitelist for tabs user wants to keep (tabId -> expiryTime)
const temporaryWhitelist = new Map();
// Track notified tabs to avoid duplicate notifications
const notifiedTabs = new Set();
// Pending close actions for notifications
const pendingCloses = new Map(); // notificationId -> { tabId, tabData }

// Initialize
initTracker();

// Set up periodic alarm
chrome.alarms.create(ALARM_NAME, { periodInMinutes: ALARM_INTERVAL });

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== ALARM_NAME) return;
  await cleanupInactiveTabs();
});

async function cleanupInactiveTabs() {
  try {
    const settings = await getSettings();
    const inactiveTabs = await getInactiveTabs(settings.inactiveThreshold);
    if (!inactiveTabs.length) return;

    // Filter out whitelisted domains
    const whitelist = settings.whitelist || [];
    const tabsToClose = inactiveTabs.filter(tab => {
      try {
        const hostname = new URL(tab.url).hostname;
        return !whitelist.some(w => hostname.includes(w));
      } catch {
        return true;
      }
    });

    // Get AI analysis and sort by importance
    const analyzed = await Promise.all(
      tabsToClose.map(async (tab) => {
        const [category, summary, importance] = await Promise.all([
          classifyTab(tab.title || '', tab.url || ''),
          summarizeTab(tab.title || '', tab.url || ''),
          getImportance(tab.title || '', tab.url || ''),
        ]);
        return { ...tab, category, summary, importance };
      })
    );

    // Protect: never close all tabs in a window
    const allWindowTabs = await chrome.tabs.query({ currentWindow: true });
    const nonAnalyzedCount = allWindowTabs.length - analyzed.length;

    // Sort: close least important first
    analyzed.sort((a, b) => a.importance - b.importance);

    let closedInThisRun = 0;
    for (const tab of analyzed) {
      // Never close the last tab in the window
      if (allWindowTabs.length - closedInThisRun <= 1) break;

      // Skip if in temporary whitelist
      const whitelistExpiry = temporaryWhitelist.get(tab.id);
      if (whitelistExpiry && Date.now() < whitelistExpiry) {
        console.log(`TabFlow: Skipping whitelisted tab ${tab.id}`);
        continue;
      } else if (whitelistExpiry) {
        // Expired, remove from whitelist
        temporaryWhitelist.delete(tab.id);
      }

      // For important tabs (importance >= 4), show notification
      if (tab.importance >= 4) {
        // Only notify once per tab
        if (notifiedTabs.has(tab.id)) {
          continue;
        }

        notifiedTabs.add(tab.id);
        const notificationId = `tab-close-warning-${tab.id}`;
        
        chrome.notifications.create(notificationId, {
          type: 'basic',
          iconUrl: tab.favIconUrl || 'assets/icon-128.png',
          title: 'TabFlow: Important Tab About to Close',
          message: `"${tab.title || 'Untitled'}" has been inactive for ${Math.round(tab.inactiveMinutes)} min`,
          buttons: [
            { title: 'Keep' },
            { title: 'Close' }
          ],
          requireInteraction: false,
          priority: 1
        });

        // Store pending close action
        pendingCloses.set(notificationId, {
          tabId: tab.id,
          tabData: {
            title: tab.title,
            url: tab.url,
            favIconUrl: tab.favIconUrl,
            category: tab.category,
            summary: tab.summary,
            importance: tab.importance
          }
        });

        // Auto-clear notification after 5 seconds
        setTimeout(() => {
          chrome.notifications.clear(notificationId);
        }, 5000);

        continue; // Don't close immediately
      }

      // For non-important tabs, close directly
      await closeTabAndSave(tab.id, {
        title: tab.title,
        url: tab.url,
        favIconUrl: tab.favIconUrl,
        category: tab.category,
        summary: tab.summary,
        importance: tab.importance
      });
      closedInThisRun++;
    }
  } catch (err) {
    console.error('TabFlow cleanup error:', err);
  }
}

// Open side panel on action click (secondary)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'openSidePanel') {
    const windowId = sender.tab?.windowId;
    if (windowId) {
      chrome.sidePanel.open({ windowId });
    } else {
      // Fallback: get current window
      chrome.windows.getCurrent().then(win => {
        chrome.sidePanel.open({ windowId: win.id });
      });
    }
    sendResponse({ ok: true });
  }
  if (msg.action === 'getClosedCount') {
    getClosedTabs().then(tabs => sendResponse({ count: tabs.length }));
    return true;
  }
});

// Update badge on startup
getClosedTabs().then(tabs => {
  if (tabs.length > 0) {
    chrome.action.setBadgeText({ text: String(tabs.length) });
    chrome.action.setBadgeBackgroundColor({ color: '#06B6D4' });
  }
});

// Handle notification button clicks
chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
  const pendingData = pendingCloses.get(notificationId);
  if (!pendingData) return;

  const { tabId, tabData } = pendingData;

  if (buttonIndex === 0) {
    // Keep button - add to temporary whitelist for 1 hour
    const expiryTime = Date.now() + 60 * 60 * 1000; // 1 hour
    temporaryWhitelist.set(tabId, expiryTime);
    console.log(`TabFlow: Tab ${tabId} added to temporary whitelist until ${new Date(expiryTime)}`);
  } else if (buttonIndex === 1) {
    // Close button - proceed with closing
    closeTabAndSave(tabId, tabData);
  }

  // Clear notification and pending data
  chrome.notifications.clear(notificationId);
  pendingCloses.delete(notificationId);
  notifiedTabs.delete(tabId);
});

// Handle notification close (no action = default close after timeout)
chrome.notifications.onClosed.addListener((notificationId, byUser) => {
  const pendingData = pendingCloses.get(notificationId);
  if (!pendingData) return;

  const { tabId, tabData } = pendingData;

  // If notification closed without user action, proceed with closing
  if (!byUser) {
    closeTabAndSave(tabId, tabData);
  }

  pendingCloses.delete(notificationId);
  notifiedTabs.delete(tabId);
});

// Helper function to close tab and save to history
async function closeTabAndSave(tabId, tabData) {
  try {
    await addClosedTab({
      title: tabData.title || 'Untitled',
      url: tabData.url,
      favIconUrl: tabData.favIconUrl || '',
      category: tabData.category,
      summary: tabData.summary,
      importance: tabData.importance,
    });

    await chrome.tabs.remove(tabId);

    // Update badge
    const closedTabs = await getClosedTabs();
    chrome.action.setBadgeText({ text: closedTabs.length > 0 ? String(closedTabs.length) : '' });
    chrome.action.setBadgeBackgroundColor({ color: '#06B6D4' });
  } catch (err) {
    console.error('TabFlow: Error closing tab', tabId, err);
  }
}

// Clean up expired whitelist entries periodically
setInterval(() => {
  const now = Date.now();
  for (const [tabId, expiryTime] of temporaryWhitelist.entries()) {
    if (now > expiryTime) {
      temporaryWhitelist.delete(tabId);
      console.log(`TabFlow: Removed expired whitelist entry for tab ${tabId}`);
    }
  }
}, 5 * 60 * 1000); // Clean every 5 minutes
