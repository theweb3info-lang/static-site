import {
  getSettings, saveSettings,
  getClosedTabs, addClosedTab, removeClosedTab, clearClosedTabs,
  getTabActivity, updateTabActivity, removeTabActivity,
  getTabCategories, setTabCategory,
} from '../utils/storage.js';

describe('Storage - Settings', () => {
  it('should return defaults when no settings saved', async () => {
    chrome.storage._reset();
    const s = await getSettings();
    assertEqual(s.inactiveThreshold, 30);
    assertEqual(s.theme, 'system');
    assert(Array.isArray(s.whitelist));
  });

  it('should save and retrieve settings', async () => {
    chrome.storage._reset();
    await saveSettings({ inactiveThreshold: 60, theme: 'dark', whitelist: ['example.com'] });
    const s = await getSettings();
    assertEqual(s.inactiveThreshold, 60);
    assertEqual(s.theme, 'dark');
  });

  it('should merge saved settings with defaults', async () => {
    chrome.storage._reset();
    await saveSettings({ inactiveThreshold: 45 });
    const s = await getSettings();
    assertEqual(s.inactiveThreshold, 45);
    // defaults should fill in missing
    assertEqual(s.theme, 'system');
  });
});

describe('Storage - Closed Tabs', () => {
  it('should return empty array when no closed tabs', async () => {
    chrome.storage._reset();
    const tabs = await getClosedTabs();
    assertDeepEqual(tabs, []);
  });

  it('should add a closed tab with timestamp', async () => {
    chrome.storage._reset();
    await addClosedTab({ title: 'Test', url: 'https://test.com' });
    const tabs = await getClosedTabs();
    assertEqual(tabs.length, 1);
    assertEqual(tabs[0].title, 'Test');
    assert(tabs[0].closedAt > 0, 'should have closedAt timestamp');
  });

  it('should prepend new tabs (most recent first)', async () => {
    chrome.storage._reset();
    await addClosedTab({ title: 'First', url: 'https://first.com' });
    await addClosedTab({ title: 'Second', url: 'https://second.com' });
    const tabs = await getClosedTabs();
    assertEqual(tabs[0].title, 'Second');
    assertEqual(tabs[1].title, 'First');
  });

  it('should cap at MAX_CLOSED_TABS', async () => {
    chrome.storage._reset();
    for (let i = 0; i < 205; i++) {
      await addClosedTab({ title: `Tab ${i}`, url: `https://t${i}.com` });
    }
    const tabs = await getClosedTabs();
    assertEqual(tabs.length, 200);
  });

  it('should remove a closed tab by URL', async () => {
    chrome.storage._reset();
    await addClosedTab({ title: 'A', url: 'https://a.com' });
    await addClosedTab({ title: 'B', url: 'https://b.com' });
    await removeClosedTab('https://a.com');
    const tabs = await getClosedTabs();
    assertEqual(tabs.length, 1);
    assertEqual(tabs[0].title, 'B');
  });

  it('should clear all closed tabs', async () => {
    chrome.storage._reset();
    await addClosedTab({ title: 'A', url: 'https://a.com' });
    await clearClosedTabs();
    const tabs = await getClosedTabs();
    assertEqual(tabs.length, 0);
  });
});

describe('Storage - Tab Activity', () => {
  it('should return empty object when no activity', async () => {
    chrome.storage._reset();
    const a = await getTabActivity();
    assertDeepEqual(a, {});
  });

  it('should update and retrieve tab activity', async () => {
    chrome.storage._reset();
    await updateTabActivity(42);
    const a = await getTabActivity();
    assert(a[42] > 0);
  });

  it('should remove tab activity', async () => {
    chrome.storage._reset();
    await updateTabActivity(42);
    await removeTabActivity(42);
    const a = await getTabActivity();
    assertEqual(a[42], undefined);
  });
});

describe('Storage - Tab Categories', () => {
  it('should return empty object when no categories', async () => {
    chrome.storage._reset();
    const c = await getTabCategories();
    assertDeepEqual(c, {});
  });

  it('should set and retrieve tab category', async () => {
    chrome.storage._reset();
    await setTabCategory(1, 'work', 'Code review', 4);
    const c = await getTabCategories();
    assertEqual(c[1].category, 'work');
    assertEqual(c[1].summary, 'Code review');
    assertEqual(c[1].importance, 4);
  });
});
