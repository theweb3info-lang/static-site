// AI Engine - Three-tier fallback: Chrome Built-in AI → Transformers.js → Rules
import { CATEGORY_RULES, IMPORTANCE_RULES } from './constants.js';

// Chrome Built-in AI state
let aiSession = null;
let chromeAIAvailable = null;

// Transformers.js state
let transformersClassifier = null;
let transformersLoading = false;
let transformersAvailable = false;

// Check Chrome Built-in AI availability
async function checkChromeAI() {
  if (chromeAIAvailable !== null) return chromeAIAvailable;
  try {
    if (typeof self !== 'undefined' && self.ai && self.ai.languageModel) {
      const caps = await self.ai.languageModel.capabilities();
      if (caps.available === 'readily') {
        chromeAIAvailable = true;
        if (!aiSession) {
          aiSession = await self.ai.languageModel.create({
            systemPrompt: 'You are a tab classification assistant. Respond only with the requested format, no extra text.',
          });
        }
      } else if (caps.available === 'after-download') {
        // Model needs download — don't block, fall back for now
        chromeAIAvailable = false;
        // Trigger download in background for future use
        self.ai.languageModel.create({
          systemPrompt: 'You are a tab classification assistant. Respond only with the requested format, no extra text.',
        }).then(session => {
          aiSession = session;
          chromeAIAvailable = true;
        }).catch(() => {});
      } else {
        chromeAIAvailable = false;
      }
    } else {
      chromeAIAvailable = false;
    }
  } catch {
    chromeAIAvailable = false;
  }
  return chromeAIAvailable;
}

// Load Transformers.js classifier (lazy, cached)
async function getTransformersClassifier() {
  if (transformersClassifier) return transformersClassifier;
  if (transformersLoading) {
    // Wait for ongoing load
    while (transformersLoading) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    return transformersClassifier;
  }

  transformersLoading = true;
  try {
    // Dynamic import for Transformers.js
    const { pipeline } = await import('@xenova/transformers');
    transformersClassifier = await pipeline(
      'zero-shot-classification',
      'Xenova/distilbert-base-uncased-mnli'
    );
    transformersAvailable = true;
    console.log('✅ Transformers.js model loaded');
    return transformersClassifier;
  } catch (err) {
    console.warn('❌ Failed to load Transformers.js:', err);
    transformersAvailable = false;
    return null;
  } finally {
    transformersLoading = false;
  }
}

// Rule-based fallback classification
function classifyByRules(title, url) {
  const combined = `${title} ${url}`.toLowerCase();
  for (const [category, patterns] of Object.entries(CATEGORY_RULES)) {
    if (patterns.some(p => p.test(combined))) return category;
  }
  return 'other';
}

// Rule-based importance (1-5)
function importanceByRules(title, url) {
  const combined = `${title} ${url}`.toLowerCase();
  if (IMPORTANCE_RULES.high.some(p => p.test(combined))) return 4;
  if (IMPORTANCE_RULES.low.some(p => p.test(combined))) return 2;
  return 3;
}

// Three-tier classification: Chrome AI → Transformers.js → Rules
export async function classifyTab(title, url) {
  // Tier 1: Chrome Built-in AI
  if (await checkChromeAI()) {
    try {
      const resp = await aiSession.prompt(
        `Classify this browser tab into exactly one category: work, study, entertainment, shopping, social, other.\nTitle: ${title}\nURL: ${url}\nRespond with just the category word.`
      );
      const cat = resp.trim().toLowerCase();
      if (['work', 'study', 'entertainment', 'shopping', 'social', 'other'].includes(cat)) {
        return cat;
      }
    } catch (err) {
      console.warn('Chrome AI failed:', err);
      // Session may be destroyed, reset for next call
      aiSession = null;
      chromeAIAvailable = null;
    }
  }

  // Tier 2: Transformers.js
  try {
    const classifier = await getTransformersClassifier();
    if (classifier) {
      const labels = ['work', 'study', 'entertainment', 'shopping', 'social', 'other'];
      const text = `${title} ${url}`.slice(0, 200); // Limit length for performance
      const result = await classifier(text, labels, { multi_label: false });
      
      // result.labels[0] is the top prediction
      if (result.labels && result.labels[0]) {
        return result.labels[0];
      }
    }
  } catch (err) {
    console.warn('Transformers.js classification failed:', err);
  }

  // Tier 3: Rule-based fallback
  return classifyByRules(title, url);
}

export async function summarizeTab(title, url) {
  // Only Chrome AI supports summarization for now
  if (await checkChromeAI()) {
    try {
      const resp = await aiSession.prompt(
        `Write a one-sentence summary (max 15 words) of what this page is about.\nTitle: ${title}\nURL: ${url}`
      );
      return resp.trim();
    } catch {
      aiSession = null;
      chromeAIAvailable = null;
    }
  }
  return title.length > 60 ? title.substring(0, 57) + '...' : title;
}

export async function getImportance(title, url) {
  // Only Chrome AI supports importance rating for now
  if (await checkChromeAI()) {
    try {
      const resp = await aiSession.prompt(
        `Rate this tab's importance from 1 (least) to 5 (most important) for productivity. Respond with just a number.\nTitle: ${title}\nURL: ${url}`
      );
      const n = parseInt(resp.trim());
      if (n >= 1 && n <= 5) return n;
    } catch {
      aiSession = null;
      chromeAIAvailable = null;
    }
  }
  return importanceByRules(title, url);
}

// Get detailed AI engine status
export async function getAIStatus() {
  const chromeAI = await checkChromeAI();
  
  return {
    chromeAI: {
      available: chromeAI,
      label: chromeAI ? '✅ Available' : '❌ Not Available'
    },
    transformers: {
      available: transformersAvailable,
      loading: transformersLoading,
      label: transformersLoading 
        ? '⏳ Loading model...' 
        : transformersAvailable 
          ? '✅ Ready (cached)' 
          : '❌ Not loaded'
    },
    rules: {
      available: true,
      label: '✅ Always Available'
    }
  };
}

// Legacy compatibility
export async function isAIAvailable() {
  return checkChromeAI();
}
