import { getClosedTabs, removeClosedTab, clearClosedTabs } from '../utils/storage.js';
import { CATEGORIES } from '../utils/constants.js';

let closedTabs = [];
let activeFilter = 'all';

async function init() {
  closedTabs = await getClosedTabs();
  renderFilters();
  renderTabs();

  document.getElementById('searchInput').addEventListener('input', renderTabs);
  document.getElementById('restoreAll').addEventListener('click', restoreAll);
  document.getElementById('clearAll').addEventListener('click', async () => {
    if (confirm('Clear all closed tabs from history?')) {
      await clearClosedTabs();
      closedTabs = [];
      renderTabs();
    }
  });

  // Listen for storage changes
  chrome.storage.onChanged.addListener(async () => {
    closedTabs = await getClosedTabs();
    renderTabs();
  });
}

function renderFilters() {
  const row = document.getElementById('filterRow');
  const counts = { all: closedTabs.length };
  closedTabs.forEach(t => {
    const cat = t.category || 'other';
    counts[cat] = (counts[cat] || 0) + 1;
  });

  let html = `<button class="filter-btn active" data-cat="all">All (${counts.all})</button>`;
  for (const [key, cat] of Object.entries(CATEGORIES)) {
    if (counts[key]) {
      html += `<button class="filter-btn" data-cat="${key}">${cat.icon} ${cat.label} (${counts[key]})</button>`;
    }
  }
  row.innerHTML = html;

  row.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      row.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeFilter = btn.dataset.cat;
      renderTabs();
    });
  });
}

function renderTabs() {
  const query = document.getElementById('searchInput').value.toLowerCase();
  let filtered = closedTabs;

  if (activeFilter !== 'all') {
    filtered = filtered.filter(t => t.category === activeFilter);
  }
  if (query) {
    filtered = filtered.filter(t =>
      (t.title || '').toLowerCase().includes(query) ||
      (t.url || '').toLowerCase().includes(query)
    );
  }

  const list = document.getElementById('tabList');
  const empty = document.getElementById('emptyState');

  if (!filtered.length) {
    list.style.display = 'none';
    empty.style.display = 'block';
    return;
  }

  empty.style.display = 'none';
  list.style.display = 'flex';

  list.innerHTML = filtered.map((tab, i) => {
    const cat = CATEGORIES[tab.category] || CATEGORIES.other;
    const ago = timeAgo(tab.closedAt);
    const fallbackIcon = 'data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 16 16%22><rect width=%2216%22 height=%2216%22 rx=%224%22 fill=%22%23e2e8f0%22/></svg>';

    return `
      <div class="tab-card" data-url="${escapeAttr(tab.url)}" data-index="${i}">
        <img class="favicon" src="${tab.favIconUrl || fallbackIcon}" onerror="this.src='${fallbackIcon}'">
        <div class="info">
          <div class="title">${escapeHtml(tab.title)}</div>
          ${tab.summary ? `<div class="summary">${escapeHtml(tab.summary)}</div>` : ''}
          <div class="meta">
            <span class="cat-badge">${cat.icon} ${cat.label}</span>
            <span>${ago}</span>
            ${tab.importance ? `<span>⭐ ${tab.importance}/5</span>` : ''}
          </div>
        </div>
        <div class="actions">
          <button data-action="restore" title="Restore">↗️</button>
          <button data-action="delete" title="Remove">🗑</button>
        </div>
      </div>
    `;
  }).join('');

  list.querySelectorAll('.tab-card').forEach(card => {
    card.addEventListener('click', (e) => {
      if (e.target.closest('button')) return;
      restoreTab(card.dataset.url);
    });

    card.querySelector('[data-action="restore"]')?.addEventListener('click', () => {
      restoreTab(card.dataset.url);
    });

    card.querySelector('[data-action="delete"]')?.addEventListener('click', async () => {
      await removeClosedTab(card.dataset.url);
      closedTabs = await getClosedTabs();
      renderFilters();
      renderTabs();
    });
  });
}

async function restoreTab(url) {
  await chrome.tabs.create({ url });
  await removeClosedTab(url);
  closedTabs = await getClosedTabs();
  renderFilters();
  renderTabs();
}

async function restoreAll() {
  for (const tab of closedTabs) {
    await chrome.tabs.create({ url: tab.url, active: false });
  }
  await clearClosedTabs();
  closedTabs = [];
  renderFilters();
  renderTabs();
}

function timeAgo(ts) {
  if (!ts) return '';
  const diff = Date.now() - ts;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

function escapeHtml(str) {
  const d = document.createElement('div');
  d.textContent = str || '';
  return d.innerHTML;
}

function escapeAttr(str) {
  return (str || '').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

init();
