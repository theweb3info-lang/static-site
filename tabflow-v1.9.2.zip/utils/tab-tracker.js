// Tab activity tracker
import { getTabActivity, updateTabActivity, removeTabActivity } from './storage.js';

export function initTracker() {
  // Track tab activation
  chrome.tabs.onActivated.addListener(({ tabId }) => {
    updateTabActivity(tabId);
  });

  // Track tab updates (navigation)
  chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (changeInfo.status === 'complete' || changeInfo.url) {
      updateTabActivity(tabId);
    }
  });

  // Clean up on tab close
  chrome.tabs.onRemoved.addListener((tabId) => {
    removeTabActivity(tabId);
  });

  // Initialize all current tabs and clean stale entries
  chrome.tabs.query({}, async (tabs) => {
    const activeIds = new Set(tabs.map(t => t.id));
    tabs.forEach(tab => {
      updateTabActivity(tab.id);
    });
    // Remove stale activity entries for tabs that no longer exist
    const activity = await getTabActivity();
    let changed = false;
    for (const id of Object.keys(activity)) {
      if (!activeIds.has(Number(id))) {
        delete activity[id];
        changed = true;
      }
    }
    if (changed) {
      chrome.storage.local.set({ tabflow_tab_activity: activity });
    }
  });
}

export async function getInactiveTabs(thresholdMinutes) {
  const activity = await getTabActivity();
  const now = Date.now();
  const threshold = thresholdMinutes * 60 * 1000;
  const tabs = await chrome.tabs.query({});

  return tabs.filter(tab => {
    if (tab.pinned) return false;
    if (tab.active) return false;
    if (tab.audible) return false;
    const url = tab.url || '';
    if (url.startsWith('chrome://') || url.startsWith('chrome-extension://') ||
        url.startsWith('about:') || url.startsWith('data:') || url.startsWith('file://') ||
        url.startsWith('devtools://') || url === '') return false;
    const lastActive = activity[tab.id];
    // Tabs with no recorded activity are treated as very old (should be closed)
    if (!lastActive) return true;
    return (now - lastActive) > threshold;
  }).map(tab => ({
    ...tab,
    lastActive: activity[tab.id] || 0,
    inactiveMinutes: activity[tab.id] ? Math.round((now - activity[tab.id]) / 60000) : Infinity,
  }));
}

export async function getTabInactiveTime(tabId) {
  const activity = await getTabActivity();
  if (!activity[tabId]) return 0;
  return Math.round((Date.now() - activity[tabId]) / 60000);
}
