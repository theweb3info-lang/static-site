// Test service worker cleanup logic
// We test the logic indirectly since the service worker runs on import
import { getSettings, saveSettings, addClosedTab, getClosedTabs } from '../utils/storage.js';
import { getInactiveTabs } from '../utils/tab-tracker.js';
import { DEFAULTS } from '../utils/constants.js';

describe('Service Worker - Cleanup Logic', () => {
  it('should not close tabs within threshold', async () => {
    chrome.storage._reset();
    const fiveMinsAgo = Date.now() - 5 * 60 * 1000;
    chrome.tabs._setTabs([
      { id: 1, pinned: false, active: false, url: 'https://test.com', windowId: 1 },
    ]);
    chrome.storage._store().tabflow_tab_activity = { 1: fiveMinsAgo };

    const inactive = await getInactiveTabs(DEFAULTS.inactiveThreshold);
    assertEqual(inactive.length, 0);
  });

  it('should identify tabs beyond threshold for closing', async () => {
    chrome.storage._reset();
    const twoHoursAgo = Date.now() - 120 * 60 * 1000;
    chrome.tabs._setTabs([
      { id: 1, pinned: false, active: false, url: 'https://test.com', title: 'Test', windowId: 1 },
    ]);
    chrome.storage._store().tabflow_tab_activity = { 1: twoHoursAgo };

    const inactive = await getInactiveTabs(DEFAULTS.inactiveThreshold);
    assertEqual(inactive.length, 1);
  });

  it('whitelist should protect tabs from closing', async () => {
    chrome.storage._reset();
    const old = Date.now() - 120 * 60 * 1000;
    chrome.tabs._setTabs([
      { id: 1, pinned: false, active: false, url: 'https://mail.google.com/inbox', windowId: 1 },
      { id: 2, pinned: false, active: false, url: 'https://random.com', windowId: 1 },
    ]);
    chrome.storage._store().tabflow_tab_activity = { 1: old, 2: old };

    const inactive = await getInactiveTabs(30);
    // Both are inactive, but whitelist filtering happens in service-worker
    // Here we just verify both come through as inactive
    assertEqual(inactive.length, 2);

    // Simulate whitelist filtering (as done in service-worker.js)
    const whitelist = DEFAULTS.whitelist;
    const toClose = inactive.filter(tab => {
      try {
        const hostname = new URL(tab.url).hostname;
        return !whitelist.some(w => hostname.includes(w));
      } catch { return true; }
    });
    assertEqual(toClose.length, 1);
    assertEqual(toClose[0].url, 'https://random.com');
  });

  it('should save tab data before simulated close', async () => {
    chrome.storage._reset();
    const tab = { title: 'Important Page', url: 'https://example.com', favIconUrl: 'https://example.com/icon.png' };
    await addClosedTab({
      ...tab,
      category: 'work',
      summary: 'Important Page',
      importance: 4,
    });
    const saved = await getClosedTabs();
    assertEqual(saved.length, 1);
    assertEqual(saved[0].title, 'Important Page');
    assertEqual(saved[0].category, 'work');
    assert(saved[0].closedAt > 0);
  });

  it('important tabs (>=4) should be delayed if inactive < 2x threshold', async () => {
    // Simulate the logic from service-worker.js
    const settings = { inactiveThreshold: 30 };
    const tab = { importance: 4, inactiveMinutes: 45 }; // < 60 (2x30)
    const shouldSkip = tab.importance >= 4 && tab.inactiveMinutes < settings.inactiveThreshold * 2;
    assert(shouldSkip, 'important tab should be delayed');
  });

  it('should never close the last tab in a window (logic check)', () => {
    // Simulate the protection logic from service-worker.js
    const allWindowTabs = [{ id: 1 }]; // only 1 tab
    const analyzed = [{ id: 1, importance: 1, inactiveMinutes: 999 }];
    let closedInThisRun = 0;
    for (const tab of analyzed) {
      if (allWindowTabs.length - closedInThisRun <= 1) break;
      closedInThisRun++;
    }
    assertEqual(closedInThisRun, 0, 'should not close the last tab');
  });

  it('important tabs should close when inactive > 2x threshold', async () => {
    const settings = { inactiveThreshold: 30 };
    const tab = { importance: 4, inactiveMinutes: 65 }; // > 60
    const shouldSkip = tab.importance >= 4 && tab.inactiveMinutes < settings.inactiveThreshold * 2;
    assert(!shouldSkip, 'important tab should be closed after 2x threshold');
  });
});
