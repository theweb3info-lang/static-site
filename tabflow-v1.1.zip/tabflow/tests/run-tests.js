// Lightweight test runner for TabFlow
// Run: node tests/run-tests.js

let totalPass = 0, totalFail = 0, totalSkip = 0;
const results = [];

globalThis.describe = (name, fn) => {
  console.log(`\n📦 ${name}`);
  fn();
};

globalThis.it = (name, fn) => {
  try {
    fn();
    totalPass++;
    console.log(`  ✅ ${name}`);
  } catch (e) {
    totalFail++;
    console.log(`  ❌ ${name}`);
    console.log(`     ${e.message}`);
  }
};

globalThis.assert = (condition, msg = 'Assertion failed') => {
  if (!condition) throw new Error(msg);
};

globalThis.assertEqual = (actual, expected, msg) => {
  if (actual !== expected) {
    throw new Error(msg || `Expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
  }
};

globalThis.assertDeepEqual = (actual, expected, msg) => {
  if (JSON.stringify(actual) !== JSON.stringify(expected)) {
    throw new Error(msg || `Expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
  }
};

// Mock Chrome APIs
function createMockStorage() {
  let store = {};
  return {
    local: {
      get: async (keys) => {
        if (typeof keys === 'string') {
          return { [keys]: store[keys] };
        }
        if (Array.isArray(keys)) {
          const result = {};
          keys.forEach(k => { if (k in store) result[k] = store[k]; });
          return result;
        }
        return { ...store };
      },
      set: async (items) => {
        Object.assign(store, items);
      },
      remove: async (keys) => {
        const arr = Array.isArray(keys) ? keys : [keys];
        arr.forEach(k => delete store[k]);
      },
      clear: async () => { store = {}; },
    },
    onChanged: { addListener: () => {} },
    _store: () => store,
    _reset: () => { store = {}; },
  };
}

function createMockTabs() {
  let tabs = [];
  const listeners = { onActivated: [], onUpdated: [], onRemoved: [] };
  return {
    query: async (q) => {
      let result = [...tabs];
      if (q.currentWindow) result = result.filter(t => t.windowId === 1);
      return result;
    },
    get: async (id) => tabs.find(t => t.id === id),
    create: async (opts) => { const t = { id: Date.now(), ...opts }; tabs.push(t); return t; },
    update: async (id, props) => {
      const t = tabs.find(t => t.id === id);
      if (t) Object.assign(t, props);
      return t;
    },
    remove: async (id) => { tabs = tabs.filter(t => t.id !== id); },
    onActivated: { addListener: (fn) => listeners.onActivated.push(fn) },
    onUpdated: { addListener: (fn) => listeners.onUpdated.push(fn) },
    onRemoved: { addListener: (fn) => listeners.onRemoved.push(fn) },
    _setTabs: (t) => { tabs = t; },
    _listeners: listeners,
  };
}

globalThis.chrome = {
  storage: createMockStorage(),
  tabs: createMockTabs(),
  alarms: {
    create: () => {},
    onAlarm: { addListener: () => {} },
  },
  action: {
    setBadgeText: () => {},
    setBadgeBackgroundColor: () => {},
  },
  runtime: {
    onMessage: { addListener: () => {} },
    sendMessage: () => {},
    openOptionsPage: () => {},
  },
  sidePanel: { open: () => {} },
};

globalThis.self = { ai: null }; // No AI available in tests

// Import and run tests
async function run() {
  console.log('🧪 TabFlow Test Suite\n' + '='.repeat(40));

  await import('./test-storage.js');
  await import('./test-tab-tracker.js');
  await import('./test-ai-engine.js');
  await import('./test-service-worker.js');

  console.log('\n' + '='.repeat(40));
  console.log(`\n📊 Results: ${totalPass} passed, ${totalFail} failed`);
  process.exit(totalFail > 0 ? 1 : 0);
}

run();
