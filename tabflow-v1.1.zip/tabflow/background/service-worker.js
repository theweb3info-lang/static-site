// TabFlow Service Worker
import { getSettings, addClosedTab, getClosedTabs } from '../utils/storage.js';
import { initTracker, getInactiveTabs } from '../utils/tab-tracker.js';
import { classifyTab, summarizeTab, getImportance } from '../utils/ai-engine.js';
import { ALARM_NAME, ALARM_INTERVAL } from '../utils/constants.js';

// Initialize
initTracker();

// Set up periodic alarm
chrome.alarms.create(ALARM_NAME, { periodInMinutes: ALARM_INTERVAL });

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== ALARM_NAME) return;
  await cleanupInactiveTabs();
});

async function cleanupInactiveTabs() {
  try {
    const settings = await getSettings();
    const inactiveTabs = await getInactiveTabs(settings.inactiveThreshold);
    if (!inactiveTabs.length) return;

    // Filter out whitelisted domains
    const whitelist = settings.whitelist || [];
    const tabsToClose = inactiveTabs.filter(tab => {
      try {
        const hostname = new URL(tab.url).hostname;
        return !whitelist.some(w => hostname.includes(w));
      } catch {
        return true;
      }
    });

    // Get AI analysis and sort by importance
    const analyzed = await Promise.all(
      tabsToClose.map(async (tab) => {
        const [category, summary, importance] = await Promise.all([
          classifyTab(tab.title || '', tab.url || ''),
          summarizeTab(tab.title || '', tab.url || ''),
          getImportance(tab.title || '', tab.url || ''),
        ]);
        return { ...tab, category, summary, importance };
      })
    );

    // Protect: never close all tabs in a window
    const allWindowTabs = await chrome.tabs.query({ currentWindow: true });
    const nonAnalyzedCount = allWindowTabs.length - analyzed.length;

    // Sort: close least important first
    analyzed.sort((a, b) => a.importance - b.importance);

    let closedInThisRun = 0;
    for (const tab of analyzed) {
      // Never close the last tab in the window
      if (allWindowTabs.length - closedInThisRun <= 1) break;
      // Delay closing important tabs (importance >= 4)
      if (tab.importance >= 4 && tab.inactiveMinutes < settings.inactiveThreshold * 2) {
        continue;
      }

      // Save before closing
      await addClosedTab({
        title: tab.title || 'Untitled',
        url: tab.url,
        favIconUrl: tab.favIconUrl || '',
        category: tab.category,
        summary: tab.summary,
        importance: tab.importance,
      });

      await chrome.tabs.remove(tab.id);
      closedInThisRun++;
    }

    // Update badge
    const closedTabs = await getClosedTabs();
    const count = closedTabs.length;
    chrome.action.setBadgeText({ text: count > 0 ? String(count) : '' });
    chrome.action.setBadgeBackgroundColor({ color: '#06B6D4' });
  } catch (err) {
    console.error('TabFlow cleanup error:', err);
  }
}

// Open side panel on action click (secondary)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'openSidePanel') {
    const windowId = sender.tab?.windowId;
    if (windowId) {
      chrome.sidePanel.open({ windowId });
    } else {
      // Fallback: get current window
      chrome.windows.getCurrent().then(win => {
        chrome.sidePanel.open({ windowId: win.id });
      });
    }
    sendResponse({ ok: true });
  }
  if (msg.action === 'getClosedCount') {
    getClosedTabs().then(tabs => sendResponse({ count: tabs.length }));
    return true;
  }
});

// Update badge on startup
getClosedTabs().then(tabs => {
  if (tabs.length > 0) {
    chrome.action.setBadgeText({ text: String(tabs.length) });
    chrome.action.setBadgeBackgroundColor({ color: '#06B6D4' });
  }
});
