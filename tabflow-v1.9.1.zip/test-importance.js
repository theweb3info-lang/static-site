// Quick test script for importance analysis
// Run: node test-importance.js

import { classifyTab } from './utils/ai-engine.js';

const testCases = [
  { title: 'GitHub - Fix critical bug #123', url: 'https://github.com/user/repo/issues/123' },
  { title: 'YouTube - Random music video', url: 'https://youtube.com/watch?v=abc123' },
  { title: 'Gmail - 3 unread messages', url: 'https://mail.google.com/mail/u/0/#inbox' },
  { title: 'Wikipedia - Random article', url: 'https://wikipedia.org/wiki/Article' },
  { title: 'Google Docs - Meeting notes draft', url: 'https://docs.google.com/document/d/abc/edit' },
  { title: 'Reddit - Funny cats compilation', url: 'https://reddit.com/r/funny/comments/abc' },
  { title: 'URGENT: Deadline ASAP - Review pending', url: 'https://notion.so/urgent-task' },
];

async function runTests() {
  console.log('🧪 Testing Importance Analysis System\n');
  
  for (const test of testCases) {
    try {
      const result = await classifyTab(test.title, test.url, true);
      console.log(`📋 "${test.title}"`);
      console.log(`   Category: ${result.category}`);
      console.log(`   Importance: ${result.importance}/5`);
      console.log(`   Reason: ${result.reason}`);
      console.log(`   Threshold multiplier: ${getMultiplier(result.importance)}x`);
      console.log('');
    } catch (err) {
      console.error(`❌ Error testing "${test.title}":`, err.message);
    }
  }
}

function getMultiplier(importance) {
  const multipliers = { 5: 3.0, 4: 2.0, 3: 1.0, 2: 0.7, 1: 0.5 };
  return multipliers[importance] || 1.0;
}

runTests().catch(console.error);
