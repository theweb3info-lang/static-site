import { classifyTab, summarizeTab, getImportance, isAIAvailable } from '../utils/ai-engine.js';

describe('AI Engine - Availability', () => {
  it('should report AI as unavailable in test env', async () => {
    const available = await isAIAvailable();
    assertEqual(available, false);
  });
});

describe('AI Engine - Rule-based Classification', () => {
  it('should classify GitHub as work', async () => {
    const cat = await classifyTab('My Repo', 'https://github.com/user/repo');
    assertEqual(cat, 'work');
  });

  it('should classify YouTube as entertainment', async () => {
    const cat = await classifyTab('Funny Video', 'https://youtube.com/watch?v=abc');
    assertEqual(cat, 'entertainment');
  });

  it('should classify Wikipedia as study', async () => {
    const cat = await classifyTab('Quantum Physics', 'https://en.wikipedia.org/wiki/Quantum');
    assertEqual(cat, 'study');
  });

  it('should classify Amazon as shopping', async () => {
    const cat = await classifyTab('Buy Stuff', 'https://amazon.com/dp/123');
    assertEqual(cat, 'shopping');
  });

  it('should classify Twitter as social', async () => {
    const cat = await classifyTab('Timeline', 'https://twitter.com/home');
    assertEqual(cat, 'social');
  });

  it('should classify x.com as social', async () => {
    const cat = await classifyTab('Timeline', 'https://x.com/home');
    assertEqual(cat, 'social');
  });

  it('should classify unknown as other', async () => {
    const cat = await classifyTab('Random Site', 'https://random-unknown-site.xyz');
    assertEqual(cat, 'other');
  });

  it('should classify Notion as work', async () => {
    const cat = await classifyTab('My Workspace', 'https://notion.so/workspace');
    assertEqual(cat, 'work');
  });

  it('should classify Reddit as entertainment', async () => {
    const cat = await classifyTab('Front Page', 'https://reddit.com/r/all');
    assertEqual(cat, 'entertainment');
  });

  it('should classify LeetCode as study', async () => {
    const cat = await classifyTab('Two Sum', 'https://leetcode.com/problems/two-sum');
    assertEqual(cat, 'study');
  });
});

describe('AI Engine - Importance Scoring', () => {
  it('should rate Google Docs as high importance', async () => {
    const score = await getImportance('My Doc', 'https://docs.google.com/document/d/123');
    assertEqual(score, 4);
  });

  it('should rate GitHub PR as high importance', async () => {
    const score = await getImportance('Fix bug #42', 'https://github.com/user/repo/pull/42');
    assertEqual(score, 4);
  });

  it('should rate Reddit as low importance', async () => {
    const score = await getImportance('Memes', 'https://reddit.com/r/funny');
    assertEqual(score, 2);
  });

  it('should rate YouTube video as low importance', async () => {
    const score = await getImportance('Cat Video', 'https://youtube.com/watch?v=cat');
    assertEqual(score, 2);
  });

  it('should rate unknown site as medium importance', async () => {
    const score = await getImportance('Some Page', 'https://example.com/page');
    assertEqual(score, 3);
  });
});

describe('AI Engine - Summarization Fallback', () => {
  it('should return title as summary when AI unavailable', async () => {
    const summary = await summarizeTab('Short Title', 'https://example.com');
    assertEqual(summary, 'Short Title');
  });

  it('should truncate long titles', async () => {
    const longTitle = 'A'.repeat(100);
    const summary = await summarizeTab(longTitle, 'https://example.com');
    assertEqual(summary.length, 60);
    assert(summary.endsWith('...'));
  });
});
