import { getSettings, saveSettings } from '../utils/storage.js';
import { getAIStatus } from '../utils/ai-engine.js';

let settings = {};

async function init() {
  settings = await getSettings();

  // Threshold
  const slider = document.getElementById('threshold');
  const valEl = document.getElementById('thresholdVal');
  slider.value = settings.inactiveThreshold;
  valEl.textContent = `${settings.inactiveThreshold} min`;
  slider.addEventListener('input', () => {
    valEl.textContent = `${slider.value} min`;
  });

  // Max tabs
  document.getElementById('maxTabs').value = settings.maxTabs || 0;

  // Theme
  document.querySelector(`input[name="theme"][value="${settings.theme || 'system'}"]`).checked = true;

  // Whitelist
  renderWhitelist();

  // AI status (detailed)
  const status = await getAIStatus();
  const statusHTML = `
    <strong>AI Engine Status:</strong><br>
    • Chrome Built-in AI: ${status.chromeAI.label}<br>
    • Transformers.js: ${status.transformers.label}<br>
    • Rule-based: ${status.rules.label}<br>
    <small style="color: var(--text-secondary);">Classification uses the first available engine in order.</small>
    
    <div style="margin-top: 16px; padding: 12px; background: var(--bg-secondary, #f0f0f0); border-radius: 8px;">
      <strong>🧠 AI Importance Analysis (Beta)</strong><br>
      <small style="color: var(--text-secondary);">Tabs are rated 1-5 for intelligent closing decisions:</small>
      
      <div style="margin-top: 8px; font-size: 13px; line-height: 1.6;">
        <strong>Example Classifications:</strong><br>
        • "GitHub - Fix critical bug" → <span style="color: #DC2626;">5 (Critical)</span><br>
        • "Gmail - 3 unread messages" → <span style="color: #EA580C;">4 (Important)</span><br>
        • "Wikipedia - Random article" → <span style="color: #CA8A04;">3 (Normal)</span><br>
        • "Reddit - Funny cats" → <span style="color: #65A30D;">2 (Low priority)</span><br>
        • "YouTube - Random video" → <span style="color: #16A34A;">1 (Can close)</span>
      </div>
      
      <div style="margin-top: 12px; font-size: 13px; line-height: 1.6;">
        <strong>Adjusted Thresholds:</strong><br>
        • Importance 5 → <strong>${settings.inactiveThreshold * 3} min</strong> (3x)<br>
        • Importance 4 → <strong>${settings.inactiveThreshold * 2} min</strong> (2x)<br>
        • Importance 3 → <strong>${settings.inactiveThreshold} min</strong> (normal)<br>
        • Importance 2 → <strong>${Math.round(settings.inactiveThreshold * 0.7)} min</strong> (0.7x)<br>
        • Importance 1 → <strong>${Math.round(settings.inactiveThreshold * 0.5)} min</strong> (0.5x)
      </div>
      
      <small style="color: var(--text-secondary); display: block; margin-top: 8px;">
        💡 Tabs with importance ≥ 4 show confirmation notification before closing.
      </small>
    </div>
  `;
  document.getElementById('aiStatus').innerHTML = statusHTML;

  // Add domain
  document.getElementById('addDomain').addEventListener('click', addDomain);
  document.getElementById('newDomain').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') addDomain();
  });

  // Save
  document.getElementById('saveBtn').addEventListener('click', save);
}

function renderWhitelist() {
  const container = document.getElementById('whitelistContainer');
  container.innerHTML = '';
  (settings.whitelist || []).forEach(domain => {
    const div = document.createElement('div');
    div.className = 'whitelist-item';
    const span = document.createElement('span');
    span.textContent = domain;
    const btn = document.createElement('button');
    btn.textContent = '✕';
    btn.title = 'Remove';
    btn.addEventListener('click', () => {
      settings.whitelist = settings.whitelist.filter(d => d !== domain);
      renderWhitelist();
    });
    div.appendChild(span);
    div.appendChild(btn);
    container.appendChild(div);
  });
}

function addDomain() {
  const input = document.getElementById('newDomain');
  const domain = input.value.trim();
  if (!domain) return;
  if (!settings.whitelist) settings.whitelist = [];
  if (!settings.whitelist.includes(domain)) {
    settings.whitelist.push(domain);
    renderWhitelist();
  }
  input.value = '';
}

async function save() {
  settings.inactiveThreshold = parseInt(document.getElementById('threshold').value);
  settings.maxTabs = parseInt(document.getElementById('maxTabs').value);
  settings.theme = document.querySelector('input[name="theme"]:checked').value;
  await saveSettings(settings);
  const msg = document.getElementById('saveMsg');
  msg.textContent = '✓ Settings saved!';
  setTimeout(() => { msg.textContent = ''; }, 2000);
}

init();
