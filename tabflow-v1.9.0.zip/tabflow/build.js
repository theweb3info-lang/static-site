import * as esbuild from 'esbuild';

const isWatch = process.argv.includes('--watch');

const buildConfig = {
  entryPoints: ['utils/ai-engine.source.js'],
  bundle: true,
  outfile: 'utils/ai-engine.js',
  format: 'esm',
  platform: 'browser',
  target: ['es2020'],
  sourcemap: false,
  minify: true,
  logLevel: 'info',
};

if (isWatch) {
  console.log('👀 Watching for changes...');
  const context = await esbuild.context(buildConfig);
  await context.watch();
} else {
  console.log('🔨 Building TabFlow AI engine...');
  await esbuild.build(buildConfig);
  console.log('✅ Build complete: utils/ai-engine.js');
}
