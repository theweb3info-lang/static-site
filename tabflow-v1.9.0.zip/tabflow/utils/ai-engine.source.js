// AI Engine - Three-tier fallback: Chrome Built-in AI → Transformers.js → Rules
import { 
  CATEGORY_RULES, 
  IMPORTANCE_RULES, 
  IMPORTANCE_KEYWORDS,
  CATEGORY_IMPORTANCE 
} from './constants.js';

// Chrome Built-in AI state
let aiSession = null;
let chromeAIAvailable = null;

// Transformers.js state
let transformersClassifier = null;
let transformersLoading = false;
let transformersAvailable = false;

// Check Chrome Built-in AI availability
async function checkChromeAI() {
  if (chromeAIAvailable !== null) return chromeAIAvailable;
  try {
    if (typeof self !== 'undefined' && self.ai && self.ai.languageModel) {
      const caps = await self.ai.languageModel.capabilities();
      if (caps.available === 'readily') {
        chromeAIAvailable = true;
        if (!aiSession) {
          aiSession = await self.ai.languageModel.create({
            systemPrompt: 'You are a tab classification assistant. Respond only with the requested format, no extra text.',
          });
        }
      } else if (caps.available === 'after-download') {
        // Model needs download — don't block, fall back for now
        chromeAIAvailable = false;
        // Trigger download in background for future use
        self.ai.languageModel.create({
          systemPrompt: 'You are a tab classification assistant. Respond only with the requested format, no extra text.',
        }).then(session => {
          aiSession = session;
          chromeAIAvailable = true;
        }).catch(() => {});
      } else {
        chromeAIAvailable = false;
      }
    } else {
      chromeAIAvailable = false;
    }
  } catch {
    chromeAIAvailable = false;
  }
  return chromeAIAvailable;
}

// Load Transformers.js classifier (lazy, cached)
async function getTransformersClassifier() {
  if (transformersClassifier) return transformersClassifier;
  if (transformersLoading) {
    // Wait for ongoing load
    while (transformersLoading) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    return transformersClassifier;
  }

  transformersLoading = true;
  try {
    // Dynamic import for Transformers.js
    const { pipeline } = await import('@xenova/transformers');
    transformersClassifier = await pipeline(
      'zero-shot-classification',
      'Xenova/distilbert-base-uncased-mnli'
    );
    transformersAvailable = true;
    console.log('✅ Transformers.js model loaded');
    return transformersClassifier;
  } catch (err) {
    console.warn('❌ Failed to load Transformers.js:', err);
    transformersAvailable = false;
    return null;
  } finally {
    transformersLoading = false;
  }
}

// Rule-based fallback classification
function classifyByRules(title, url) {
  const combined = `${title} ${url}`.toLowerCase();
  for (const [category, patterns] of Object.entries(CATEGORY_RULES)) {
    if (patterns.some(p => p.test(combined))) return category;
  }
  return 'other';
}

// Rule-based importance (1-5)
function importanceByRules(title, url) {
  const combined = `${title} ${url}`.toLowerCase();
  if (IMPORTANCE_RULES.high.some(p => p.test(combined))) return 4;
  if (IMPORTANCE_RULES.low.some(p => p.test(combined))) return 2;
  return 3;
}

// Keyword-based importance bonus (-2 to +2)
function keywordImportanceBonus(title) {
  const lowerTitle = title.toLowerCase();
  let bonus = 0;
  
  for (const word of IMPORTANCE_KEYWORDS.high) {
    if (lowerTitle.includes(word)) bonus += 0.5;
  }
  
  for (const word of IMPORTANCE_KEYWORDS.low) {
    if (lowerTitle.includes(word)) bonus -= 0.5;
  }
  
  return Math.max(-2, Math.min(2, bonus)); // Clamp to -2 to +2
}

// URL pattern analysis for importance hints
function analyzeUrlPattern(url) {
  try {
    const urlLower = url.toLowerCase();
    
    // High importance patterns
    if (urlLower.includes('unread')) return 1;
    if (urlLower.includes('inbox')) return 0.5;
    if (urlLower.includes('edit')) return 0.5;
    if (urlLower.includes('compose')) return 0.5;
    
    // Low importance patterns
    if (urlLower.includes('watch?v=')) return -0.5; // YouTube video
    if (urlLower.includes('/r/')) return -0.5; // Reddit
    if (urlLower.includes('trending')) return -0.5;
    
    return 0;
  } catch {
    return 0;
  }
}

// AI-powered importance analysis with Chrome AI
async function analyzeImportanceWithAI(title, url) {
  if (await checkChromeAI()) {
    try {
      const prompt = `Analyze this browser tab and rate its importance (1-5):
Title: "${title}"
URL: ${url}

Consider:
- Is it work-related or personal?
- Does it contain urgent keywords (deadline, critical, unread)?
- Is it temporary content (random browsing) or important work?

Reply with ONLY a number 1-5 and brief reason:
1 = Can close immediately (random browsing)
2 = Low priority
3 = Normal
4 = Important (active work, unread messages)
5 = Critical (don't close, urgent work)

Format: "4 - Active draft document"`;

      const result = await aiSession.prompt(prompt);
      const match = result.trim().match(/^(\d)/);
      if (match) {
        const score = parseInt(match[1]);
        if (score >= 1 && score <= 5) {
          const reason = result.split('-').slice(1).join('-').trim() || 'AI analysis';
          return { score, reason };
        }
      }
    } catch (err) {
      console.warn('Chrome AI importance analysis failed:', err);
      aiSession = null;
      chromeAIAvailable = null;
    }
  }
  return null;
}

// Comprehensive importance calculation with AI + keywords + URL patterns
async function calculateImportance(title, url, category) {
  let baseScore = CATEGORY_IMPORTANCE[category] || 3;
  
  // Try AI analysis first (if available)
  let aiResult = null;
  try {
    aiResult = await analyzeImportanceWithAI(title, url);
  } catch (err) {
    // AI failed, will fall back to rules
  }
  
  // Keyword analysis (always run)
  const keywordBonus = keywordImportanceBonus(title);
  
  // URL pattern analysis
  const urlBonus = analyzeUrlPattern(url);
  
  // Calculate final score
  let finalScore;
  if (aiResult !== null) {
    // AI available: use AI score as base, add 30% of keyword influence
    finalScore = aiResult.score + (keywordBonus * 0.3);
  } else {
    // No AI: use category base + keyword bonus + URL bonus
    finalScore = baseScore + keywordBonus + urlBonus;
  }
  
  // Clamp to 1-5 range and round
  finalScore = Math.max(1, Math.min(5, Math.round(finalScore)));
  
  const reason = aiResult ? aiResult.reason : (
    keywordBonus > 0 ? 'Contains important keywords' :
    keywordBonus < 0 ? 'Casual browsing content' :
    'Standard activity'
  );
  
  return { score: finalScore, reason };
}

// Three-tier classification: Chrome AI → Transformers.js → Rules
// Returns: { category, importance, reason } or just category string (legacy compat)
export async function classifyTab(title, url, fullAnalysis = false) {
  let category = 'other';
  
  // Tier 1: Chrome Built-in AI
  if (await checkChromeAI()) {
    try {
      const resp = await aiSession.prompt(
        `Classify this browser tab into exactly one category: work, study, entertainment, shopping, social, other.\nTitle: ${title}\nURL: ${url}\nRespond with just the category word.`
      );
      const cat = resp.trim().toLowerCase();
      if (['work', 'study', 'entertainment', 'shopping', 'social', 'other'].includes(cat)) {
        category = cat;
      }
    } catch (err) {
      console.warn('Chrome AI failed:', err);
      // Session may be destroyed, reset for next call
      aiSession = null;
      chromeAIAvailable = null;
    }
  }

  // Tier 2: Transformers.js (if Chrome AI didn't work)
  if (category === 'other') {
    try {
      const classifier = await getTransformersClassifier();
      if (classifier) {
        const labels = ['work', 'study', 'entertainment', 'shopping', 'social', 'other'];
        const text = `${title} ${url}`.slice(0, 200); // Limit length for performance
        const result = await classifier(text, labels, { multi_label: false });
        
        // result.labels[0] is the top prediction
        if (result.labels && result.labels[0]) {
          category = result.labels[0];
        }
      }
    } catch (err) {
      console.warn('Transformers.js classification failed:', err);
    }
  }

  // Tier 3: Rule-based fallback
  if (category === 'other') {
    category = classifyByRules(title, url);
  }
  
  // If full analysis requested, calculate importance
  if (fullAnalysis) {
    const { score, reason } = await calculateImportance(title, url, category);
    return {
      category,
      importance: score,
      reason
    };
  }
  
  // Legacy mode: return just category string
  return category;
}

export async function summarizeTab(title, url) {
  // Only Chrome AI supports summarization for now
  if (await checkChromeAI()) {
    try {
      const resp = await aiSession.prompt(
        `Write a one-sentence summary (max 15 words) of what this page is about.\nTitle: ${title}\nURL: ${url}`
      );
      return resp.trim();
    } catch {
      aiSession = null;
      chromeAIAvailable = null;
    }
  }
  return title.length > 60 ? title.substring(0, 57) + '...' : title;
}

export async function getImportance(title, url) {
  // Only Chrome AI supports importance rating for now
  if (await checkChromeAI()) {
    try {
      const resp = await aiSession.prompt(
        `Rate this tab's importance from 1 (least) to 5 (most important) for productivity. Respond with just a number.\nTitle: ${title}\nURL: ${url}`
      );
      const n = parseInt(resp.trim());
      if (n >= 1 && n <= 5) return n;
    } catch {
      aiSession = null;
      chromeAIAvailable = null;
    }
  }
  return importanceByRules(title, url);
}

// Get detailed AI engine status
export async function getAIStatus() {
  const chromeAI = await checkChromeAI();
  
  return {
    chromeAI: {
      available: chromeAI,
      label: chromeAI ? '✅ Available' : '❌ Not Available'
    },
    transformers: {
      available: transformersAvailable,
      loading: transformersLoading,
      label: transformersLoading 
        ? '⏳ Loading model...' 
        : transformersAvailable 
          ? '✅ Ready (cached)' 
          : '❌ Not loaded'
    },
    rules: {
      available: true,
      label: '✅ Always Available'
    }
  };
}

// Legacy compatibility
export async function isAIAvailable() {
  return checkChromeAI();
}
