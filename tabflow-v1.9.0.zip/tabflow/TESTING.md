# Testing TabFlow Transformers.js Integration

## Pre-test Setup
1. Run `npm run build` to generate `utils/ai-engine.js`
2. Load the extension in Chrome (`chrome://extensions/`)

## Test 1: Chrome AI Available
**Goal:** Verify Chrome AI is prioritized when available

1. Open Chrome Canary/Dev with AI enabled
2. Open Settings (`chrome://extensions/` → TabFlow → Options)
3. Check AI Status section:
   - Should show: Chrome Built-in AI: ✅ Available
4. Open a few tabs (e.g., GitHub, YouTube, Amazon)
5. Check console logs in background service worker
6. Should see tabs classified using Chrome AI (no Transformers.js load)

## Test 2: Transformers.js Fallback
**Goal:** Verify Transformers.js loads when Chrome AI unavailable

1. Use Chrome Stable (without Built-in AI) OR disable AI flag
2. Open Settings
3. Check AI Status:
   - Chrome Built-in AI: ❌ Not Available
   - Transformers.js: ⏳ Loading model... → ✅ Ready (cached)
4. Open a few test tabs
5. Check console for "✅ Transformers.js model loaded"
6. Tabs should be classified correctly

## Test 3: Rule-based Fallback
**Goal:** Verify rules work if both AI engines fail

1. Simulate Transformers.js failure (disconnect network during first load)
2. Open tabs with obvious domains (github.com, youtube.com, amazon.com)
3. Should still classify correctly using regex rules

## Test 4: Model Caching
**Goal:** Verify model caches and doesn't re-download

1. After Test 2, reload the extension
2. Open new tabs
3. Check Network panel: no new model downloads
4. Check console: should not see "Loading model" message
5. Classification should be instant (~50-100ms)

## Test 5: Performance
**Goal:** Verify classification speed is acceptable

1. Open 10 tabs quickly
2. Monitor classification time in console
3. Expected: 
   - Chrome AI: ~100-200ms per tab
   - Transformers.js: ~50-100ms per tab (after load)
   - Rules: <10ms per tab

## Test 6: Options Page Status
**Goal:** Verify status display updates correctly

1. Open Options page
2. Check all three engines show correct status
3. Test in both Chrome with AI and without AI
4. Status should update immediately

## Known Issues
- Model download: ~15MB first time (2-5 seconds on good connection)
- Service worker restart clears in-memory classifier (will reload from IndexedDB cache)

## Console Debug Commands
```javascript
// In service worker console:
import { getAIStatus } from './utils/ai-engine.js';
const status = await getAIStatus();
console.log(status);
```

## Expected Console Output
### With Chrome AI:
```
TabFlow: Classifying tab [GitHub] using Chrome AI
```

### With Transformers.js:
```
✅ Transformers.js model loaded
TabFlow: Classifying tab [GitHub] using Transformers.js
```

### With Rules:
```
TabFlow: Classifying tab [github.com/...] using rules
```
