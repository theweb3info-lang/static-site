# Intelligent Importance Analysis System

## Overview
Extended TabFlow's AI capabilities to intelligently assess tab importance (1-5 scale) and adjust closing thresholds accordingly, preventing premature closure of critical work tabs while aggressively closing low-value browsing tabs.

## Implementation Summary ✅

### 1. Enhanced Constants (`utils/constants.js`)
**Added:**
- `IMPORTANCE_KEYWORDS`: Keyword-based importance detection
  - **High keywords:** urgent, deadline, asap, critical, important, meeting, draft, editing, unread, pending, todo, task, in progress, wip, review, approval, overdue
  - **Low keywords:** random, browse, explore, watch, funny, meme, entertainment, video, music, game, cat, dog, viral, trending, lol, wtf
  
- `CATEGORY_IMPORTANCE`: Base importance scores by category
  - work: 4, study: 4, entertainment: 2, shopping: 3, social: 2, other: 3
  
- `IMPORTANCE_MULTIPLIERS`: Threshold multipliers based on importance
  - 5 (Critical): 3.0x threshold (e.g., 90 min instead of 30 min)
  - 4 (Important): 2.0x threshold (e.g., 60 min)
  - 3 (Normal): 1.0x threshold (default)
  - 2 (Low priority): 0.7x threshold (e.g., 21 min)
  - 1 (Can close): 0.5x threshold (e.g., 15 min)

### 2. AI Engine Extensions (`utils/ai-engine.source.js`)
**Added Functions:**
- `keywordImportanceBonus(title)`: Analyzes title for importance keywords, returns -2 to +2 bonus
- `analyzeUrlPattern(url)`: Detects importance hints in URLs (unread, inbox, edit, watch, trending)
- `analyzeImportanceWithAI(title, url)`: Chrome AI-powered importance analysis with detailed prompt
- `calculateImportance(title, url, category)`: Comprehensive scoring system:
  - Tries AI first (if available)
  - Falls back to category base + keyword bonus + URL bonus
  - Returns `{ score: 1-5, reason: string }`

**Enhanced Functions:**
- `classifyTab(title, url, fullAnalysis = false)`: Now supports full analysis mode
  - **Legacy mode** (`fullAnalysis=false`): Returns category string (backward compatible)
  - **Full mode** (`fullAnalysis=true`): Returns `{ category, importance, reason }`

### 3. Service Worker Improvements (`background/service-worker.js`)
**Key Changes:**
- Import `IMPORTANCE_MULTIPLIERS` from constants
- Use `classifyTab()` with `fullAnalysis=true` to get category + importance + reason in one call
- Apply importance-based threshold multipliers:
  ```javascript
  const multiplier = IMPORTANCE_MULTIPLIERS[tab.importance] || 1.0;
  const adjustedThreshold = baseThreshold * multiplier;
  ```
- Enhanced notification messages:
  - Show importance score (e.g., "Importance: 4/5")
  - Display adjusted threshold (e.g., "60/60 min")
  - Include reason from AI analysis
- Console logging for debugging threshold calculations

### 4. Options Page UI (`options/options.js`)
**Added:**
- New "AI Importance Analysis (Beta)" section showing:
  - Example classifications with color-coded importance levels
  - Adjusted thresholds dynamically calculated based on user's settings
  - Explanation of notification behavior for important tabs (≥4)

**Example Display:**
```
🧠 AI Importance Analysis (Beta)
Example Classifications:
• "GitHub - Fix critical bug" → 5 (Critical)
• "Gmail - 3 unread messages" → 4 (Important)
• "Wikipedia - Random article" → 3 (Normal)
• "Reddit - Funny cats" → 2 (Low priority)
• "YouTube - Random video" → 1 (Can close)

Adjusted Thresholds:
• Importance 5 → 90 min (3x)
• Importance 4 → 60 min (2x)
• Importance 3 → 30 min (normal)
• Importance 2 → 21 min (0.7x)
• Importance 1 → 15 min (0.5x)

💡 Tabs with importance ≥ 4 show confirmation notification before closing.
```

## Git Commits
```
36da729 feat: add keyword-based importance detection
d6d53a4 feat: add AI-powered intelligent importance analysis
286aca9 feat: apply importance-based closing thresholds
d5a503e feat: display importance analysis examples in options page
```

## User Experience Improvements

### Before:
- All tabs in the same category closed at the same threshold
- "GitHub - Fix critical bug" closed after 30 min (same as entertainment)
- "Gmail - 3 unread messages" closed without warning

### After:
- **Critical tabs** (importance 5):
  - 3x longer threshold (90 min instead of 30 min)
  - Confirmation notification before closing
  
- **Important tabs** (importance 4):
  - 2x longer threshold (60 min)
  - Confirmation notification
  
- **Low-priority tabs** (importance 1-2):
  - 0.5-0.7x shorter threshold (15-21 min)
  - No notification, immediate close

### Example Scenarios:
| Tab | Old Behavior | New Behavior |
|-----|--------------|--------------|
| "GitHub - Fix critical bug #123" | work=4, closes at 30 min | importance=5, closes at 90 min with notification |
| "YouTube - Random music" | entertainment=2, closes at 30 min | importance=1, closes at 15 min |
| "Gmail - 3 unread messages" | work=4, closes at 30 min | importance=5, closes at 90 min with notification |
| "Wikipedia - 随便看看" | news=3, closes at 30 min | importance=2, closes at 21 min |
| "Google Docs - Meeting notes draft" | work=4, closes at 30 min | importance=5, closes at 90 min with notification |

## Technical Quality

### ✅ Backward Compatibility
- `classifyTab()` maintains legacy string return by default
- Existing code continues to work without changes

### ✅ Graceful Degradation
- AI analysis fails → falls back to keyword analysis
- Keyword analysis insufficient → uses category base score
- No disruption to functionality

### ✅ Performance
- Importance analysis runs asynchronously with classification
- No blocking operations
- Efficient keyword matching (linear scan, optimized patterns)

### ✅ User Control
- Thresholds still user-configurable in Options
- Multipliers apply to user's chosen base threshold
- Whitelist still prevents closing of protected domains

## Testing Checklist

- [ ] Load extension and verify build succeeded
- [ ] Check Options page displays importance examples correctly
- [ ] Test high-importance tab (e.g., Gmail with "unread" in title)
  - Should show notification before closing
  - Should have 2x or 3x threshold
- [ ] Test low-importance tab (e.g., YouTube watch page)
  - Should close faster (0.5x threshold)
  - No notification
- [ ] Verify console logs show threshold calculations
- [ ] Test with different base thresholds (5 min, 60 min)
- [ ] Verify keyword detection works (create tab with "urgent" or "deadline" in title)

## Future Enhancements

1. **User-configurable multipliers:** Let users adjust 1x/2x/3x thresholds
2. **Learning mode:** Track which tabs users manually "Keep" and adjust scoring
3. **Domain-specific rules:** Allow custom importance rules per domain
4. **Visual indicators:** Show importance badge on tab icons
5. **History analysis:** Learn from past tab usage patterns

## Rollback Plan

If issues arise:
```bash
cd /Users/andy_crab/.openclaw/workspace/tabflow
git revert d5a503e  # Revert options UI
git revert 286aca9  # Revert service worker thresholds
git revert d6d53a4  # Revert AI analysis
git revert 36da729  # Revert constants
npm run build       # Rebuild
```

Extension will fall back to previous behavior (uniform thresholds, no importance-based adjustments).
