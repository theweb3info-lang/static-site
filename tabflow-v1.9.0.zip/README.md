# TabFlow — Smart Tab Manager

A Chrome extension that automatically manages inactive tabs with AI-powered categorization and summaries.

## Features

### Core (V1.0)
- **Auto-close inactive tabs** — configurable threshold (default 30 min), respects pinned tabs & whitelist
- **Recovery list** — browse, search, and restore closed tabs via side panel
- **Popup panel** — view all open tabs, inactive time, quick pin/close actions
- **Settings** — threshold, whitelist, max tabs, dark/light theme

### AI-Powered (V1.5+)
- **Smart categorization** — Work / Study / Entertainment / Shopping / Social / Other
- **One-line summaries** — AI-generated page summaries saved before closing
- **Importance scoring** — important tabs get delayed closing (1-5 scale)
- **Three-tier AI fallback** (V1.7):
  1. **Chrome Built-in AI** (Gemini Nano) — fastest, no download
  2. **Transformers.js** (DistilBERT) — offline ML model (~15MB, cached)
  3. **Rule-based** — regex patterns, always available

## Tech Stack
- Chrome Extension Manifest V3
- **AI Engine:** Chrome Built-in AI → Transformers.js → Rules
- **ML Model:** @xenova/transformers (DistilBERT zero-shot classification)
- **Build:** esbuild for bundling dependencies
- Modern CSS with dark/light mode support

## Install

### For Users
1. Open `chrome://extensions/`
2. Enable **Developer mode**
3. Click **Load unpacked** → select the `tabflow/` folder

### For Developers
1. Clone the repo
2. Install dependencies: `npm install`
3. Build the AI engine: `npm run build`
4. Load unpacked extension in Chrome

**Note:** The AI engine uses Transformers.js which requires bundling. The source file is `utils/ai-engine.source.js`, and `npm run build` generates the production `utils/ai-engine.js`.

## Permissions
- `tabs` — monitor and manage tabs
- `storage` — persist settings and closed tab history
- `activeTab` — capture tab info
- `sidePanel` — recovery list panel
- `alarms` — periodic cleanup checks
