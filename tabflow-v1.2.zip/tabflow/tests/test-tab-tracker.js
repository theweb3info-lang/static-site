import { getInactiveTabs, getTabInactiveTime } from '../utils/tab-tracker.js';
import { updateTabActivity } from '../utils/storage.js';

describe('Tab Tracker - Inactive Tabs', () => {
  it('should exclude pinned tabs', async () => {
    chrome.storage._reset();
    chrome.tabs._setTabs([
      { id: 1, pinned: true, active: false, url: 'https://test.com', windowId: 1 },
      { id: 2, pinned: false, active: false, url: 'https://test2.com', windowId: 1 },
    ]);
    // Set activity to 2 hours ago
    const twoHoursAgo = Date.now() - 120 * 60 * 1000;
    const store = chrome.storage._store();
    store.tabflow_tab_activity = { 1: twoHoursAgo, 2: twoHoursAgo };

    const inactive = await getInactiveTabs(30);
    assert(!inactive.find(t => t.id === 1), 'pinned tab should be excluded');
    assert(inactive.find(t => t.id === 2), 'unpinned inactive tab should be included');
  });

  it('should exclude active tabs', async () => {
    chrome.storage._reset();
    chrome.tabs._setTabs([
      { id: 1, pinned: false, active: true, url: 'https://test.com', windowId: 1 },
    ]);
    const inactive = await getInactiveTabs(30);
    assertEqual(inactive.length, 0);
  });

  it('should exclude chrome:// URLs', async () => {
    chrome.storage._reset();
    const old = Date.now() - 120 * 60 * 1000;
    chrome.tabs._setTabs([
      { id: 1, pinned: false, active: false, url: 'chrome://extensions', windowId: 1 },
    ]);
    chrome.storage._store().tabflow_tab_activity = { 1: old };

    const inactive = await getInactiveTabs(30);
    assertEqual(inactive.length, 0);
  });

  it('should exclude chrome-extension:// URLs', async () => {
    chrome.storage._reset();
    const old = Date.now() - 120 * 60 * 1000;
    chrome.tabs._setTabs([
      { id: 1, pinned: false, active: false, url: 'chrome-extension://abc/page.html', windowId: 1 },
    ]);
    chrome.storage._store().tabflow_tab_activity = { 1: old };

    const inactive = await getInactiveTabs(30);
    assertEqual(inactive.length, 0);
  });

  it('should respect threshold', async () => {
    chrome.storage._reset();
    const tenMinsAgo = Date.now() - 10 * 60 * 1000;
    chrome.tabs._setTabs([
      { id: 1, pinned: false, active: false, url: 'https://test.com', windowId: 1 },
    ]);
    chrome.storage._store().tabflow_tab_activity = { 1: tenMinsAgo };

    // 30 min threshold - tab is only 10 min inactive
    let inactive = await getInactiveTabs(30);
    assertEqual(inactive.length, 0);

    // 5 min threshold - tab is 10 min inactive
    inactive = await getInactiveTabs(5);
    assertEqual(inactive.length, 1);
  });

  it('should include inactiveMinutes in result', async () => {
    chrome.storage._reset();
    const old = Date.now() - 60 * 60 * 1000; // 1 hour
    chrome.tabs._setTabs([
      { id: 1, pinned: false, active: false, url: 'https://test.com', title: 'Test', windowId: 1 },
    ]);
    chrome.storage._store().tabflow_tab_activity = { 1: old };

    const inactive = await getInactiveTabs(30);
    assertEqual(inactive.length, 1);
    assert(inactive[0].inactiveMinutes >= 59 && inactive[0].inactiveMinutes <= 61);
  });
});

describe('Tab Tracker - Edge Cases', () => {
  it('should exclude audible tabs', async () => {
    chrome.storage._reset();
    const old = Date.now() - 120 * 60 * 1000;
    chrome.tabs._setTabs([
      { id: 1, pinned: false, active: false, audible: true, url: 'https://spotify.com', windowId: 1 },
    ]);
    chrome.storage._store().tabflow_tab_activity = { 1: old };
    const inactive = await getInactiveTabs(30);
    assertEqual(inactive.length, 0);
  });

  it('should exclude about:blank URLs', async () => {
    chrome.storage._reset();
    const old = Date.now() - 120 * 60 * 1000;
    chrome.tabs._setTabs([
      { id: 1, pinned: false, active: false, url: 'about:blank', windowId: 1 },
    ]);
    chrome.storage._store().tabflow_tab_activity = { 1: old };
    const inactive = await getInactiveTabs(30);
    assertEqual(inactive.length, 0);
  });

  it('should exclude data: URLs', async () => {
    chrome.storage._reset();
    const old = Date.now() - 120 * 60 * 1000;
    chrome.tabs._setTabs([
      { id: 1, pinned: false, active: false, url: 'data:text/html,hello', windowId: 1 },
    ]);
    chrome.storage._store().tabflow_tab_activity = { 1: old };
    const inactive = await getInactiveTabs(30);
    assertEqual(inactive.length, 0);
  });

  it('should exclude file:// URLs', async () => {
    chrome.storage._reset();
    const old = Date.now() - 120 * 60 * 1000;
    chrome.tabs._setTabs([
      { id: 1, pinned: false, active: false, url: 'file:///home/test.html', windowId: 1 },
    ]);
    chrome.storage._store().tabflow_tab_activity = { 1: old };
    const inactive = await getInactiveTabs(30);
    assertEqual(inactive.length, 0);
  });

  it('should exclude tabs with empty URL', async () => {
    chrome.storage._reset();
    const old = Date.now() - 120 * 60 * 1000;
    chrome.tabs._setTabs([
      { id: 1, pinned: false, active: false, url: '', windowId: 1 },
    ]);
    chrome.storage._store().tabflow_tab_activity = { 1: old };
    const inactive = await getInactiveTabs(30);
    assertEqual(inactive.length, 0);
  });
});

describe('Tab Tracker - Inactive Time', () => {
  it('should return 0 for unknown tab', async () => {
    chrome.storage._reset();
    const time = await getTabInactiveTime(999);
    assertEqual(time, 0);
  });

  it('should return minutes of inactivity', async () => {
    chrome.storage._reset();
    const tenMinsAgo = Date.now() - 10 * 60 * 1000;
    chrome.storage._store().tabflow_tab_activity = { 5: tenMinsAgo };
    const time = await getTabInactiveTime(5);
    assert(time >= 9 && time <= 11, `Expected ~10, got ${time}`);
  });
});
