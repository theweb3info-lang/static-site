// AI Engine - Chrome Built-in AI with rule-based fallback
import { CATEGORY_RULES, IMPORTANCE_RULES } from './constants.js';

let aiSession = null;
let aiAvailable = null;

async function checkAI() {
  if (aiAvailable !== null) return aiAvailable;
  try {
    if (typeof self !== 'undefined' && self.ai && self.ai.languageModel) {
      const caps = await self.ai.languageModel.capabilities();
      if (caps.available === 'readily') {
        aiAvailable = true;
        if (!aiSession) {
          aiSession = await self.ai.languageModel.create({
            systemPrompt: 'You are a tab classification assistant. Respond only with the requested format, no extra text.',
          });
        }
      } else if (caps.available === 'after-download') {
        // Model needs download — don't block, fall back to rules for now
        aiAvailable = false;
        // Trigger download in background for future use
        self.ai.languageModel.create({
          systemPrompt: 'You are a tab classification assistant. Respond only with the requested format, no extra text.',
        }).then(session => {
          aiSession = session;
          aiAvailable = true;
        }).catch(() => {});
      } else {
        aiAvailable = false;
      }
    } else {
      aiAvailable = false;
    }
  } catch {
    aiAvailable = false;
  }
  return aiAvailable;
}

// Rule-based fallback classification
function classifyByRules(title, url) {
  const combined = `${title} ${url}`.toLowerCase();
  for (const [category, patterns] of Object.entries(CATEGORY_RULES)) {
    if (patterns.some(p => p.test(combined))) return category;
  }
  return 'other';
}

// Rule-based importance (1-5)
function importanceByRules(title, url) {
  const combined = `${title} ${url}`.toLowerCase();
  if (IMPORTANCE_RULES.high.some(p => p.test(combined))) return 4;
  if (IMPORTANCE_RULES.low.some(p => p.test(combined))) return 2;
  return 3;
}

export async function classifyTab(title, url) {
  if (await checkAI()) {
    try {
      const resp = await aiSession.prompt(
        `Classify this browser tab into exactly one category: work, study, entertainment, shopping, social, other.\nTitle: ${title}\nURL: ${url}\nRespond with just the category word.`
      );
      const cat = resp.trim().toLowerCase();
      if (['work', 'study', 'entertainment', 'shopping', 'social', 'other'].includes(cat)) return cat;
    } catch {
      // Session may be destroyed, reset for next call
      aiSession = null;
      aiAvailable = null;
    }
  }
  return classifyByRules(title, url);
}

export async function summarizeTab(title, url) {
  if (await checkAI()) {
    try {
      const resp = await aiSession.prompt(
        `Write a one-sentence summary (max 15 words) of what this page is about.\nTitle: ${title}\nURL: ${url}`
      );
      return resp.trim();
    } catch {
      aiSession = null;
      aiAvailable = null;
    }
  }
  return title.length > 60 ? title.substring(0, 57) + '...' : title;
}

export async function getImportance(title, url) {
  if (await checkAI()) {
    try {
      const resp = await aiSession.prompt(
        `Rate this tab's importance from 1 (least) to 5 (most important) for productivity. Respond with just a number.\nTitle: ${title}\nURL: ${url}`
      );
      const n = parseInt(resp.trim());
      if (n >= 1 && n <= 5) return n;
    } catch {
      aiSession = null;
      aiAvailable = null;
    }
  }
  return importanceByRules(title, url);
}

export async function isAIAvailable() {
  return checkAI();
}
