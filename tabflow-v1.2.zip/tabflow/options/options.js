import { getSettings, saveSettings } from '../utils/storage.js';
import { isAIAvailable } from '../utils/ai-engine.js';

let settings = {};

async function init() {
  settings = await getSettings();

  // Threshold
  const slider = document.getElementById('threshold');
  const valEl = document.getElementById('thresholdVal');
  slider.value = settings.inactiveThreshold;
  valEl.textContent = `${settings.inactiveThreshold} min`;
  slider.addEventListener('input', () => {
    valEl.textContent = `${slider.value} min`;
  });

  // Max tabs
  document.getElementById('maxTabs').value = settings.maxTabs || 0;

  // Theme
  document.querySelector(`input[name="theme"][value="${settings.theme || 'system'}"]`).checked = true;

  // Whitelist
  renderWhitelist();

  // AI status
  const hasAI = await isAIAvailable();
  document.getElementById('aiStatus').textContent = hasAI
    ? '✅ Chrome Built-in AI (Gemini Nano) is available'
    : '⚠️ AI not available — using rule-based classification';

  // Add domain
  document.getElementById('addDomain').addEventListener('click', addDomain);
  document.getElementById('newDomain').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') addDomain();
  });

  // Save
  document.getElementById('saveBtn').addEventListener('click', save);
}

function renderWhitelist() {
  const container = document.getElementById('whitelistContainer');
  container.innerHTML = '';
  (settings.whitelist || []).forEach(domain => {
    const div = document.createElement('div');
    div.className = 'whitelist-item';
    const span = document.createElement('span');
    span.textContent = domain;
    const btn = document.createElement('button');
    btn.textContent = '✕';
    btn.title = 'Remove';
    btn.addEventListener('click', () => {
      settings.whitelist = settings.whitelist.filter(d => d !== domain);
      renderWhitelist();
    });
    div.appendChild(span);
    div.appendChild(btn);
    container.appendChild(div);
  });
}

function addDomain() {
  const input = document.getElementById('newDomain');
  const domain = input.value.trim();
  if (!domain) return;
  if (!settings.whitelist) settings.whitelist = [];
  if (!settings.whitelist.includes(domain)) {
    settings.whitelist.push(domain);
    renderWhitelist();
  }
  input.value = '';
}

async function save() {
  settings.inactiveThreshold = parseInt(document.getElementById('threshold').value);
  settings.maxTabs = parseInt(document.getElementById('maxTabs').value);
  settings.theme = document.querySelector('input[name="theme"]:checked').value;
  await saveSettings(settings);
  const msg = document.getElementById('saveMsg');
  msg.textContent = '✓ Settings saved!';
  setTimeout(() => { msg.textContent = ''; }, 2000);
}

init();
