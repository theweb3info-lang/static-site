# TabFlow — Smart Tab Manager

A Chrome extension that automatically manages inactive tabs with AI-powered categorization and summaries.

## Features

### Core (V1.0)
- **Auto-close inactive tabs** — configurable threshold (default 30 min), respects pinned tabs & whitelist
- **Recovery list** — browse, search, and restore closed tabs via side panel
- **Popup panel** — view all open tabs, inactive time, quick pin/close actions
- **Settings** — threshold, whitelist, max tabs, dark/light theme

### AI-Powered (V1.5)
- **Smart categorization** — Work / Study / Entertainment / Shopping / Social / Other
- **One-line summaries** — AI-generated page summaries saved before closing
- **Importance scoring** — important tabs get delayed closing (1-5 scale)
- **Graceful degradation** — falls back to rule-based classification when Chrome AI is unavailable

## Tech Stack
- Chrome Extension Manifest V3
- Chrome Built-in AI (Gemini Nano) with rule-based fallback
- Modern CSS with dark/light mode support

## Install
1. Open `chrome://extensions/`
2. Enable **Developer mode**
3. Click **Load unpacked** → select the `tabflow/` folder

## Permissions
- `tabs` — monitor and manage tabs
- `storage` — persist settings and closed tab history
- `activeTab` — capture tab info
- `sidePanel` — recovery list panel
- `alarms` — periodic cleanup checks
