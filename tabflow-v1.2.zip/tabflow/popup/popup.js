import { getClosedTabs, getSettings, addClosedTab } from '../utils/storage.js';
import { getTabInactiveTime } from '../utils/tab-tracker.js';
import { classifyTab } from '../utils/ai-engine.js';
import { CATEGORIES } from '../utils/constants.js';

let allTabs = [];
let sortByInactive = false;

async function loadTabs() {
  const tabs = await chrome.tabs.query({ currentWindow: true });
  const settings = await getSettings();

  allTabs = await Promise.all(tabs.map(async (tab) => {
    const inactiveMin = tab.active ? 0 : await getTabInactiveTime(tab.id);
    const category = await classifyTab(tab.title || '', tab.url || '');
    return { ...tab, inactiveMin, category };
  }));

  renderTabs(allTabs);
  updateStats();
}

function renderTabs(tabs) {
  const list = document.getElementById('tabList');
  const query = document.getElementById('searchInput').value.toLowerCase();

  let filtered = tabs;
  if (query) {
    filtered = tabs.filter(t =>
      (t.title || '').toLowerCase().includes(query) ||
      (t.url || '').toLowerCase().includes(query)
    );
  }

  if (sortByInactive) {
    filtered = [...filtered].sort((a, b) => b.inactiveMin - a.inactiveMin);
  }

  list.innerHTML = filtered.map(tab => {
    const cat = CATEGORIES[tab.category] || CATEGORIES.other;
    const inactiveText = tab.inactiveMin > 0 ? `${tab.inactiveMin}m` : 'active';
    const inactiveClass = tab.inactiveMin >= 15 ? 'tab-inactive' : '';

    return `
      <div class="tab-item" data-id="${tab.id}">
        <img class="tab-favicon" src="${tab.favIconUrl || 'data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 16 16%22><rect width=%2216%22 height=%2216%22 rx=%224%22 fill=%22%23e2e8f0%22/></svg>'}" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 16 16%22><rect width=%2216%22 height=%2216%22 rx=%224%22 fill=%22%23e2e8f0%22/></svg>'">
        <div class="tab-info">
          <div class="tab-title">${escapeHtml(tab.title || 'Untitled')}</div>
          <div class="tab-meta">
            <span class="tab-category">${cat.icon} ${cat.label}</span>
            <span class="${inactiveClass}">${inactiveText}</span>
          </div>
        </div>
        <div class="tab-actions">
          <button class="pin-btn ${tab.pinned ? 'pinned' : ''}" title="${tab.pinned ? 'Unpin' : 'Pin'}" data-action="pin">📌</button>
          <button class="close-btn" title="Close tab" data-action="close">✕</button>
        </div>
      </div>
    `;
  }).join('');

  // Event listeners
  list.querySelectorAll('.tab-item').forEach(el => {
    el.addEventListener('click', (e) => {
      if (e.target.closest('button')) return;
      chrome.tabs.update(parseInt(el.dataset.id), { active: true });
    });

    el.querySelector('[data-action="close"]')?.addEventListener('click', async () => {
      const tabId = parseInt(el.dataset.id);
      const tab = allTabs.find(t => t.id === tabId);
      if (tab) {
        await addClosedTab({
          title: tab.title || 'Untitled',
          url: tab.url,
          favIconUrl: tab.favIconUrl || '',
          category: tab.category,
          summary: tab.title,
          importance: 3,
        });
        await chrome.tabs.remove(tabId);
        el.style.animation = 'fadeOut 0.2s ease';
        setTimeout(() => loadTabs(), 200);
      }
    });

    el.querySelector('[data-action="pin"]')?.addEventListener('click', async () => {
      const tabId = parseInt(el.dataset.id);
      const tab = await chrome.tabs.get(tabId);
      await chrome.tabs.update(tabId, { pinned: !tab.pinned });
      loadTabs();
    });
  });
}

async function updateStats() {
  const tabs = await chrome.tabs.query({ currentWindow: true });
  const closedTabs = await getClosedTabs();
  document.getElementById('openCount').textContent = `${tabs.length} open`;
  document.getElementById('closedCount').textContent = `${closedTabs.length} saved`;
}

function escapeHtml(str) {
  const d = document.createElement('div');
  d.textContent = str;
  return d.innerHTML;
}

// Init
document.getElementById('searchInput').addEventListener('input', () => renderTabs(allTabs));
document.getElementById('sortBtn').addEventListener('click', () => {
  sortByInactive = !sortByInactive;
  renderTabs(allTabs);
});
document.getElementById('openSidePanel').addEventListener('click', async () => {
  if (chrome.sidePanel) {
    chrome.runtime.sendMessage({ action: 'openSidePanel' });
  } else {
    // Fallback: open side panel page as a new tab
    chrome.tabs.create({ url: chrome.runtime.getURL('sidepanel/panel.html') });
  }
});
document.getElementById('openOptions').addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});

loadTabs();
